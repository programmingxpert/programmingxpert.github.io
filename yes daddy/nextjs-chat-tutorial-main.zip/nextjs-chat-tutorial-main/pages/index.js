import React from "react";

export default function Auth() {
  return <div className="background">auth</div>;
}
