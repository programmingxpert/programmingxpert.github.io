import React from "react";

export default function Chats() {
  return <div className="background">chats</div>;
}
